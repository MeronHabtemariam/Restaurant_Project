package restaurant.menu;

import java.awt.*;
import java.awt.event.ActionEvent;
import javax.swing.*;

public class Menu extends JMenuBar {
    public Menu(CardLayout cardLayout, JPanel mainPanel) {
        JMenu menu = new JMenu("Options");

        JMenuItem gotohome = new JMenuItem("Home");
        JMenuItem gotomenu = new JMenuItem("Menu");
        JMenuItem gotoexit = new JMenuItem("Exit");

        gotohome.addActionListener((ActionEvent e) -> cardLayout.show(mainPanel, "Home"));
        gotomenu.addActionListener((ActionEvent e) -> cardLayout.show(mainPanel, "Menu"));
        gotoexit.addActionListener((ActionEvent e) -> System.exit(0));

        menu.add(gotohome);
        menu.add(gotomenu);
        menu.add(gotoexit);
        add(menu);
    }
}
