package restaurant.panels;

import java.awt.*;
import javax.swing.*;

public class MenuPanel extends JPanel {
    public MenuPanel() {
        setLayout(new BorderLayout());

        JLabel label = new JLabel("Our Menu", JLabel.CENTER);
        label.setFont(new Font("Times New Roman", Font.BOLD, 18));

        String[] menuItems = {
                "----- FOOD -----",
                " ",
                "Chicken - 15 000 UGX",
                "Pizza - 25 000 UGX",
                "Katogo - 8 000 UGX",
                "Salad - 5 000 UGX",
                "Kikomando - 5 000 UGX",
                "Rice with beans - 8 000 UGX",
                "Burger - 15 000 UGX",
                " ",
                "----- DRINKS -----",
                " ",
                "Water - 2 000 UGX",
                "Soda - 3 000 UGX",
                "Juice - 7 000 UGX",
        };

        JList<String> foodlist = new JList<>(menuItems);
        foodlist.setFont(new Font("Times New Roman", Font.PLAIN, 16));

        add(label, BorderLayout.NORTH);
        add(new JScrollPane(foodlist), BorderLayout.CENTER);
    }
}
