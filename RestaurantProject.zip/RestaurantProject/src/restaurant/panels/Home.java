package restaurant.panels;

import java.awt.*;
import javax.swing.*;

public class Home extends JPanel {
    public Home() {
        setLayout(new BorderLayout());
        JLabel homeL = new JLabel("WELCOME! LET'S EAT ", JLabel.CENTER);
        homeL.setFont(new Font("Arial", Font.BOLD, 20));
        add(homeL, BorderLayout.CENTER);
    }
}
