package restaurant;

import java.awt.*;
import javax.swing.*;
import restaurant.panels.Home;
import restaurant.panels.MenuPanel;
import restaurant.menu.Menu;

public class Restaurant extends JFrame {
    private CardLayout cardlayout1;
    private JPanel mainpage;

    public Restaurant() {
        setTitle("Restaurant Menu");
        setSize(500, 500);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        cardlayout1 = new CardLayout();
        mainpage = new JPanel(cardlayout1);

        Home home = new Home();
        MenuPanel menuPanel = new MenuPanel();

        mainpage.add(home, "Home");
        mainpage.add(menuPanel, "Menu");

        setJMenuBar(new Menu(cardlayout1, mainpage));

        add(mainpage);
    }

    public static void main(String[] args) {
        Restaurant app = new Restaurant();
        app.setVisible(true);
    }
}
