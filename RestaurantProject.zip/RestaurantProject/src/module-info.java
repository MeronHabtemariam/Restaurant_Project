module restaurant {
    requires java.desktop;
    exports restaurant;
    exports restaurant.panels;
    exports restaurant.menu;
}
